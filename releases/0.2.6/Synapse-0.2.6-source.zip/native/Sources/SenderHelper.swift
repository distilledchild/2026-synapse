import Foundation

// A separate process keeps Automation prompts and AppleScript off the UI thread.
// NSAppleScript executes on this helper's main thread. No message data is logged.
@main
struct SenderHelper {
    static func main() {
        let arguments = Array(CommandLine.arguments.dropFirst())
        let validationOnly = arguments == ["--check-target"]
        let outcome: SendOutcome
        if (arguments.isEmpty || validationOnly),
           let data = try? FileHandle.standardInput.readToEnd(), data.count <= 131_072,
           let request = try? JSONDecoder().decode(SendRequest.self, from: data), request.isValid,
           let script = NSAppleScript(source: MessageScript.source) {
            var error: NSDictionary?
            let result = script.executeAppleEvent(MessageScript.event(for: request, validationOnly: validationOnly), error: &error)
            if let error {
                outcome = (error[NSAppleScript.errorNumber] as? Int) == -1743 ? .permissionDenied : .unknown
            } else {
                outcome = result.stringValue.flatMap(SendOutcome.init(rawValue:)) ?? .unknown
            }
        } else {
            outcome = .invalidRequest
        }
        if let data = try? JSONEncoder().encode(outcome) { FileHandle.standardOutput.write(data) }
    }
}
