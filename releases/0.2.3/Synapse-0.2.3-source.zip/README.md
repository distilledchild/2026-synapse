# 2026-synapse: Unified Messaging Hub

여러 메신저의 대화를 하나의 macOS 데스크톱 앱에서 확인·검색하고, 지원 가능한 범위에서 답장하기 위한 로컬 우선 통합 메시징 프로젝트입니다.

**현재 상태: Apple 메시지 읽기·텍스트 전송 로컬 알파 0.2.3.** 연락처 이름·이니셜 표시와 간결한 작성창을 추가했습니다. 기존 iMessage·SMS·RCS 대화의 작성창, 대화별 초안, Apple 메시지 앱을 통한 텍스트 전송을 구현했습니다. SwiftUI 앱과 테스트는 `native/`, 설치 파일·소스·안내서는 `releases/0.2.3/`에 있습니다. 실제 계정 발신과 자동화 권한 승인은 사용자 테스트가 필요합니다. 새 대화·첨부 전송·수정·삭제는 미지원입니다.

- [설치 파일](releases/0.2.3/Synapse-0.2.3-arm64.dmg)
- [설치 안내](releases/0.2.3/Synapse-local-test-guide.md)
- [앱 소스와 재빌드 방법](native/README.md)

## 제품 방향

- 플랫폼별 대화를 시간순 인박스로 통합하고 계정·플랫폼별로 필터링.
- 로컬 캐시와 전체 텍스트 검색; 인증 정보는 Keychain, 저장 데이터는 암호화하는 설계.
- 초기 iMessage·Telegram 수신 검증 후 검색·답장·추가 커넥터를 단계적으로 구현.
- macOS 직접 설치 DMG를 목표로 하며, 출시 시 서명·공증과 실제 설치를 검증.

로컬 저장 암호화와 원래 메시징 서비스의 E2EE는 별개입니다. 서비스별 접근 권한과 기능 차이가 있으므로 모든 대화·모든 플랫폼 지원을 보장하지 않습니다.

## 기술 기준안

현재 로컬 알파는 **SwiftUI + Swift + 시스템 SQLite**로 만들었으며 대화를 메모리에서 조회합니다. 장기 통합 앱의 기술 기준안은 **Tauri v2 + React + TypeScript, Rust 코어, SQLite 호환 암호화 저장소와 FTS5 검색**이며 아직 구현하지 않았습니다. Telegram은 TDLib, iMessage는 로컬 DB 읽기 전용 접근을 먼저 검증합니다. 추가 Node/Go 런타임은 커넥터 필요성이 확인될 때 도입합니다.

## 플랫폼 범위

| 순서 | 대상 | 계획 상태 |
|---|---|---|
| 첫 로컬 알파 | iMessage/SMS/RCS | 열람·검색·자동 갱신, 기존 대화 텍스트 전송 구현; 실제 배달 검증 필요 |
| 다음 플랫폼 | Telegram | 미구현 |
| 우선 확장 | Slack, Discord | Slack은 승인 범위; Discord는 공식 봇 모드만 검토 |
| 후속 후보 | WhatsApp, Instagram, Facebook Messenger, X, Threads, TikTok, Twitch, KakaoTalk, LINE, Signal, LinkedIn | 접근 가능성·인증·배포 조건 검증 후 채택 |

15개는 장기 후보 수입니다. 실제 지원표는 수신·이력·발신·수정·삭제·첨부 등 기능별 검증 결과로 관리할 예정입니다.

## 현재 파일

```text
2026-synapse/
├── README.md
├── .gitignore
├── doc/plan.md
├── native/                  # SwiftUI 앱, DB 리더, 테스트, 빌드 스크립트
├── spikes/imessage/         # 최초 Python 읽기 검증
└── releases/0.2.3/          # DMG, 소스 ZIP, 체크섬, 설치 안내
```

장기 구조, 데이터 모델, 커넥터 계약, 단계별 완료 기준은 [구현 계획](doc/plan.md)에 정리했습니다. 현재 알파의 검증 결과와 한계는 [native/INSTALL.md](native/INSTALL.md)를 참고하세요.

## 실행·빌드·테스트

Apple Silicon Mac과 Apple 개발 도구에서 다음 명령을 실행합니다.

```sh
bash native/scripts/test.sh
bash native/scripts/build.sh
bash native/scripts/package.sh
```

앱과 DMG는 `native/build/`에 생성됩니다. 기존 0.1.0 DMG는 `releases/0.1.0/`에 보관합니다. 실제 메시지 발신·삭제를 수행하는 테스트는 없습니다.

## 텍스트 작성·전송

- 샘플 모드에서 작성 후 **샘플 전송**으로 화면 흐름을 확인합니다. 실제 메시지는 전송하지 않습니다.
- **메시지 연결** 후 기존 iMessage·SMS·RCS 대화를 선택하고 작성 → **전송** 또는 **⌘Enter**. Enter는 줄바꿈입니다. 첫 전송 때 macOS 자동화 권한이 필요합니다.
- 초안은 대화마다 메모리에 유지하며 앱 종료·연결 해제 때 지워집니다. 전송 중에는 추가 전송과 연결 전환을 막습니다.
- 요청 완료는 상대방 수신 확인이 아닙니다. 오류 때 초안을 보존하며 결과 불명은 메시지 앱에서 확인한 후 수동으로 다시 전송할 수 있습니다. 자동 재시도나 앱 재시작 시 전송 재개는 없습니다.
- **DB 선택**으로 연 파일은 항상 읽기 전용입니다. 원본 DB에 직접 쓰지 않고 메시지 앱의 전송 명령을 사용합니다.

## 연락처 이름 표시

메시지 연결 후 왼쪽 아래 **연락처 이름 표시**를 누르고 macOS 연락처 접근을 허용하세요. 저장된 이름과 이니셜이 대화 목록에 나타납니다. 등록되지 않거나 여러 연락처와 일치하는 번호는 번호와 사람 아이콘을 유지합니다. 이름·기존 번호 모두 검색할 수 있습니다. 연락처는 수정하거나 외부로 보내지 않으며 이름 캐시는 메모리에만 보관합니다.
