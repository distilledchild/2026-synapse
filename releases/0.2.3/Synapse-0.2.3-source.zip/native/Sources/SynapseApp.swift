import SwiftUI
import AppKit
import UniformTypeIdentifiers
import Contacts

struct InboxView: View {
    @ObservedObject var model: InboxModel
    @State private var showHelp = false
    @Environment(\.scenePhase) private var scenePhase
    private let accent = Color(red: 0.43, green: 0.34, blue: 0.88)
    var body: some View {
        NavigationSplitView {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 10) {
                    Image(systemName: "bubble.left.and.bubble.right.fill").font(.system(size: 24)).foregroundStyle(accent)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Synapse").font(.system(size: 23, weight: .bold, design: .rounded))
                        Text("모든 대화의 시작").font(.caption).foregroundStyle(.secondary)
                    }
                }.padding(20)
                HStack {
                    Label("Apple 메시지", systemImage: "message.fill").font(.headline)
                    Spacer()
                    Text(model.isDemo ? "샘플" : model.error == nil ? "연결됨" : "연결 필요")
                        .font(.caption2.bold()).padding(.horizontal, 8).padding(.vertical, 4)
                        .background(accent.opacity(0.12), in: Capsule()).foregroundStyle(accent)
                }.padding(.horizontal, 20).padding(.bottom, 12)
                TextField("대화·메시지 검색", text: $model.search)
                    .textFieldStyle(.roundedBorder).padding(.horizontal, 16).padding(.bottom, 12)
                List(selection: $model.selectedID) {
                    ForEach(model.conversations) { conversation in
                        HStack(alignment: .top, spacing: 11) {
                            ZStack {
                                Circle().fill(accent.opacity(0.12)).frame(width: 36, height: 36)
                                if let initials = NamePresentation.initials(for: conversation.title) {
                                    Text(initials).font(.system(size: 13, weight: .semibold)).foregroundStyle(accent)
                                } else {
                                    Image(systemName: "person.fill").font(.system(size: 14)).foregroundStyle(accent)
                                }
                            }
                            VStack(alignment: .leading, spacing: 5) {
                                Text(conversation.title).font(.system(size: 13, weight: .semibold)).lineLimit(1)
                                Text(conversation.last.text).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(2)
                            }
                            Spacer(minLength: 0)
                        }.padding(.vertical, 7).tag(conversation.id)
                    }
                }.listStyle(.sidebar)
                Divider()
                VStack(alignment: .leading, spacing: 10) {
                    if model.isLiveConnection {
                        if model.isLoadingContacts {
                            Label("연락처 이름을 불러오는 중…", systemImage: "person.crop.circle").font(.caption).foregroundStyle(.secondary)
                        } else if model.contactAccess == .notRequested {
                            Button { model.refreshContactNames(requestPermission: true) } label: {
                                Label("연락처 이름 표시", systemImage: "person.crop.circle")
                            }.font(.caption)
                        } else if model.contactAccess == .denied || model.contactAccess == .restricted {
                            Button("연락처 권한 설정") { model.openContactsPrivacy() }.font(.caption)
                        } else if model.contactsError {
                            Button("연락처 이름 다시 불러오기") { model.refreshContactNames(invalidate: true) }.font(.caption)
                        }
                    }
                    if model.isDemo {
                        Button { model.connect() } label: {
                            Label("메시지 연결", systemImage: "link").frame(maxWidth: .infinity)
                        }.buttonStyle(.borderedProminent).tint(accent).controlSize(.large)
                    } else {
                        HStack {
                            Toggle("자동 새로고침", isOn: $model.autoRefresh).toggleStyle(.switch).controlSize(.mini)
                            Spacer()
                            Button("연결 해제") { model.disconnect() }.font(.caption).disabled(model.isSending)
                        }
                    }
                    HStack {
                        Label("이 Mac에서만 처리", systemImage: "lock.shield").font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }.buttonStyle(.plain)
                    }
                }.padding(16)
            }.navigationSplitViewColumnWidth(min: 260, ideal: 300, max: 380)
        } detail: {
            VStack(spacing: 0) {
                if model.isDemo {
                    HStack {
                        Image(systemName: "sparkles")
                        Text("샘플 대화입니다. 메시지를 연결하면 실제 대화를 읽어옵니다.")
                        Spacer()
                    }.font(.callout).padding(14).background(accent.opacity(0.08))
                }
                if let error = model.error {
                    permissionView(error)
                } else if model.isLoading && model.snapshot.messages.isEmpty {
                    Spacer(); ProgressView("메시지를 읽고 있습니다…"); Spacer()
                } else if let conversation = model.selected {
                    conversationView(conversation)
                } else {
                    Spacer()
                    Image(systemName: "bubble.left.and.text.bubble.right").font(.system(size: 48)).foregroundStyle(accent.opacity(0.6))
                    Text(model.search.isEmpty ? "표시할 대화가 없습니다" : "검색 결과가 없습니다").font(.title2.bold()).padding(.top, 12)
                    Text(model.search.isEmpty ? "메시지 앱의 동기화 상태를 확인하거나 다른 데이터베이스를 선택하세요." : "검색은 불러온 최근 메시지 안에서 수행됩니다.")
                        .foregroundStyle(.secondary).padding().multilineTextAlignment(.center)
                    Spacer()
                }
                Divider()
                HStack(spacing: 12) {
                    Circle().fill(model.error != nil ? Color.orange : model.isDemo ? Color.gray : Color.green).frame(width: 6, height: 6)
                    Text(model.isDemo ? "샘플 \(model.snapshot.sourceRows)개" : "최근 \(model.snapshot.sourceRows)개 메시지 · 최대 \(model.snapshot.limit)개")
                    if model.snapshot.unavailableCount > 0 { Text("본문 미지원 \(model.snapshot.unavailableCount)개").foregroundStyle(.orange) }
                    Spacer()
                    if model.isLoading { ProgressView().controlSize(.small) }
                    if let date = model.lastUpdated { Text(date, style: .time) }
                    Text(model.isLiveConnection ? "읽기·텍스트 전송 · 로컬 알파" : model.isDemo ? "샘플 · 로컬 알파" : "선택한 DB · 읽기 전용").foregroundStyle(.secondary)
                }.font(.caption).foregroundStyle(.secondary).padding(12)
            }.frame(minWidth: 540)
        }
        .frame(minWidth: 900, minHeight: 620)
        .toolbar {
            ToolbarItemGroup {
                Button { model.chooseDatabase() } label: { Label("DB 선택", systemImage: "folder") }.help("다른 chat.db 파일 선택").disabled(model.isSending)
                Button { model.refresh() } label: { Label("새로고침", systemImage: "arrow.clockwise") }
                    .disabled(model.isDemo || model.isLoading).keyboardShortcut("r", modifiers: .command)
                Button { showHelp = true } label: { Label("도움말", systemImage: "info.circle") }
            }
        }
        .sheet(isPresented: $showHelp) { helpView }
        .onChange(of: scenePhase) { phase in
            if phase == .active { model.refreshContactNames(invalidate: true) }
        }
        .onReceive(NotificationCenter.default.publisher(for: .CNContactStoreDidChange)) { _ in
            model.refreshContactNames(invalidate: true)
        }
        .onChange(of: model.search) { _ in
            if !model.conversations.contains(where: { $0.id == model.selectedID }) { model.selectedID = model.conversations.first?.id }
        }
    }
    private func permissionView(_ message: String) -> some View {
        VStack(alignment: .leading, spacing: 20) {
            Spacer()
            Image(systemName: "lock.shield").font(.system(size: 44)).foregroundStyle(accent)
            Text("메시지 접근을 허용해 주세요").font(.title.bold())
            Text(message).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            VStack(alignment: .leading, spacing: 12) {
                Text("1. Synapse를 응용 프로그램 폴더로 옮겨 실행하세요.")
                Text("2. 시스템 설정 → 개인정보 보호 및 보안 → 전체 디스크 접근 권한에서 Synapse를 추가하고 켜세요.")
                Text("3. Synapse를 완전히 종료한 뒤 다시 열고, 메시지를 연결하세요.")
            }.font(.callout)
            HStack {
                Button("시스템 설정 열기") { model.openPrivacy() }.buttonStyle(.borderedProminent).tint(accent)
                Button("다시 시도") { model.refresh() }
                Button("샘플로 돌아가기") { model.disconnect() }
            }
            Text("메시지 원본은 변경하지 않습니다. 권한을 켜도 자동으로 발신하지 않습니다.").font(.caption).foregroundStyle(.secondary)
            Spacer()
        }.padding(44).frame(maxWidth: 720, maxHeight: .infinity)
    }
    private func conversationView(_ conversation: Conversation) -> some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(conversation.title).font(.title2.bold()).textSelection(.enabled)
                    Text("\(model.isDemo ? "샘플" : conversation.serviceLabel) · 불러온 메시지 \(conversation.messages.count)개").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Button { openMessages() } label: { Image(systemName: "message.fill").foregroundStyle(.green).font(.title2) }
                    .buttonStyle(.plain).help("Apple 메시지 앱 열기")
            }.padding(24)
            Divider()
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 16) {
                        ForEach(conversation.messages.filter { model.matchesSearch($0, title: conversation.title) }) { message in
                            HStack(alignment: .bottom) {
                                if message.isFromMe { Spacer(minLength: 70) }
                                VStack(alignment: message.isFromMe ? .trailing : .leading, spacing: 5) {
                                    if !message.isFromMe && conversation.id.contains(";+;") {
                                        Text(model.senderName(message.sender)).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    VStack(alignment: .leading, spacing: 7) {
                                        Text(message.text).font(.system(size: 14)).textSelection(.enabled).fixedSize(horizontal: false, vertical: true)
                                        if message.hasAttachment { Label("첨부 미리보기는 다음 버전에 제공됩니다", systemImage: "paperclip").font(.caption2) }
                                        if message.bodyUnavailable { Label("지원하지 않는 본문 형식", systemImage: "exclamationmark.circle").font(.caption2) }
                                    }.padding(.horizontal, 16).padding(.vertical, 12)
                                        .foregroundStyle(message.isFromMe ? Color.white : Color.primary)
                                        .background(message.isFromMe ? accent : Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 17))
                                    if let date = message.date { Text(date.formatted(date: .abbreviated, time: .shortened)).font(.caption2).foregroundStyle(.secondary) }
                                }.frame(maxWidth: 540, alignment: message.isFromMe ? .trailing : .leading)
                                if !message.isFromMe { Spacer(minLength: 70) }
                            }.id(message.id)
                        }
                    }.padding(24)
                }
                .onChange(of: conversation.id) { _ in if let last = conversation.messages.last, model.search.isEmpty { proxy.scrollTo(last.id, anchor: .bottom) } }
                .onAppear { if let last = conversation.messages.last, model.search.isEmpty { proxy.scrollTo(last.id, anchor: .bottom) } }
                .onChange(of: conversation.messages.last?.id) { id in if let id, model.search.isEmpty { proxy.scrollTo(id, anchor: .bottom) } }
            }
            composer(conversation)
        }
    }
    private func composer(_ conversation: Conversation) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Divider()
            if model.canCompose(in: conversation.id) {
                if model.isDemo {
                    Text("샘플 작성 · 실제 전송되지 않습니다").font(.caption).foregroundStyle(.secondary)
                }
                TextEditor(text: Binding(get: { model.draft(for: conversation.id) },
                    set: { model.setDraft($0, for: conversation.id) }))
                    .font(.body).frame(minHeight: 64, maxHeight: 110)
                    .padding(6).background(Color(nsColor: .textBackgroundColor), in: RoundedRectangle(cornerRadius: 8))
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.secondary.opacity(0.25)))
                    .overlay(alignment: .topLeading) {
                        if model.draft(for: conversation.id).isEmpty {
                            Text("메시지 입력…").font(.body).foregroundStyle(.tertiary).padding(12).allowsHitTesting(false)
                        }
                    }
                    .accessibilityLabel("메시지 작성")
                    .disabled(model.sendingChatID == conversation.id)
                    .id(conversation.id)
                if let result = model.sendResults[conversation.id], result != .accepted && result != .ready {
                    Text(result.message).font(.caption)
                        .foregroundStyle(result == .accepted ? Color.secondary : Color.orange)
                        .fixedSize(horizontal: false, vertical: true)
                    if result == .permissionDenied {
                        Button("자동화 설정 열기") { model.openAutomationPrivacy() }
                    }
                    if result == .unknown {
                        Button("메시지 앱에서 전송 여부를 확인했습니다") { model.acknowledgeUnknown(for: conversation.id) }
                    }
                }
                HStack {
                    if model.isSending {
                        ProgressView().controlSize(.small)
                        Text(model.sendingChatID == conversation.id ? "메시지 앱에 요청 중…" : "다른 대화에 전송 중…").font(.caption)
                    } else {
                        if model.sendResults[conversation.id] == .accepted {
                            Label("전송 요청됨", systemImage: "checkmark").font(.caption).foregroundStyle(.secondary)
                                .help(SendOutcome.accepted.message)
                        } else {
                            Text("⌘Enter 전송").font(.caption).foregroundStyle(.tertiary)
                        }
                    }
                    Spacer()
                    if model.draft(for: conversation.id).utf8.count > 14_000 {
                        Text("\(model.draft(for: conversation.id).utf8.count)/\(SendRequest.maximumBytes) B")
                            .font(.caption2).foregroundStyle(.orange)
                    }
                    Button(model.isDemo ? "샘플 전송" : "전송") { model.send(to: conversation.id) }
                        .buttonStyle(.borderedProminent).tint(accent)
                        .keyboardShortcut(.return, modifiers: .command)
                        .disabled(!model.canSend(to: conversation.id))
                }
            } else {
                Text(model.isLiveConnection ? "\(conversation.serviceLabel) 대화의 전송 대상을 확인할 수 없거나 아직 발신을 지원하지 않습니다. 대화의 서비스 정보와 메시지 앱 연결 상태를 확인하세요." : "선택한 DB는 읽기 전용입니다. 실제 전송은 ‘메시지 연결’로 연결한 대화에서 가능합니다.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }.padding(16)
    }
    private func openMessages() {
        if let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: "com.apple.MobileSMS") {
            NSWorkspace.shared.openApplication(at: url, configuration: NSWorkspace.OpenConfiguration())
        }
    }
    private var helpView: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Synapse 로컬 테스트 안내").font(.title2.bold())
            Text("Apple 메시지의 최근 2,000개 메시지를 읽고, 대화별로 확인하고 검색합니다. 연결 중에는 5초마다 갱신합니다.")
            Text("불러온 대화와 초안은 메모리에서 처리하며 앱 종료·연결 해제 시 지워집니다. 전송 버튼을 누르면 Apple 메시지 앱을 통해 선택한 대화로 텍스트를 보냅니다.")
            Text("‘연락처 이름 표시’를 누르고 접근을 허용하면 이 Mac에 저장된 연락처 이름과 이니셜을 표시합니다. 등록되지 않은 번호는 번호로 남습니다. 연락처 이름은 메모리에만 보관합니다.")
            Text("첫 전송 시 macOS 자동화 권한을 허용하세요. 전송 요청 완료는 상대방 수신 확인과 다릅니다. 결과 불명인 경우 메시지 앱에서 먼저 확인하세요.")
            Text("일반 텍스트와 표준 attributedBody 문자열을 지원합니다. iMessage·SMS·RCS 기존 대화에 텍스트 전송을 요청할 수 있습니다. 새 대화, 첨부·리액션 전송, 수정·삭제는 아직 지원하지 않습니다.")
            Text("SMS·RCS 수신·전송은 Apple 메시지 앱과 iPhone의 연결·문자 메시지 전달 설정에 따릅니다.")
            Text("개인 개발용 서명으로 만든 공증되지 않은 Apple Silicon 테스트판입니다.").font(.caption).foregroundStyle(.secondary)
            HStack { Spacer(); Button("확인") { showHelp = false }.keyboardShortcut(.defaultAction) }
        }.padding(30).frame(width: 570)
    }
}

@main
struct SynapseApp: App {
    @StateObject private var model = InboxModel()
    var body: some Scene {
        WindowGroup("Synapse") { InboxView(model: model).tint(Color(red: 0.43, green: 0.34, blue: 0.88)) }
            .defaultSize(width: 1120, height: 760)
            .commands { CommandGroup(replacing: .newItem) {} }
    }
}
