import Foundation

struct SendRequest: Codable, Sendable, Equatable {
    let id: UUID
    let chatID: String
    let text: String
    var service: String? = nil
    var photo: PhotoAttachment? = nil

    static let maximumBytes = 16_384
    static let supportedServices: Set<String> = ["iMessage", "SMS", "RCS"]
    var isValid: Bool {
        Self.isSupportedChat(chatID, service: service) &&
            (photo.map { $0.isValid && text.isEmpty } ?? Self.isValidText(text))
    }
    static func isValidText(_ text: String) -> Bool {
        !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        text.utf8.count <= maximumBytes && !text.contains("\0")
    }
    static func isSupportedChat(_ id: String, service: String? = nil) -> Bool {
        let parts = id.split(separator: ";", maxSplits: 2, omittingEmptySubsequences: false)
        guard parts.count == 3 else { return false }
        // Modern chat.db GUIDs use "any" for iMessage, SMS and RCS alike.
        // Require chat.service_name for those IDs; never guess the service from the handle.
        let prefix = String(parts[0])
        let supportsService = (supportedServices.contains(prefix) && (service == nil || service == prefix)) ||
            (prefix == "any" && service.map(supportedServices.contains) == true)
        return supportsService &&
            (parts[1] == "+" || parts[1] == "-") && !parts[2].isEmpty &&
            id.utf8.count <= 1024 && !id.unicodeScalars.contains { CharacterSet.controlCharacters.contains($0) }
    }
}

enum SendOutcome: String, Codable, Sendable {
    case accepted, ready, permissionDenied, targetUnavailable, invalidRequest, attachmentUnavailable, unavailable, unknown
    var message: String {
        switch self {
        case .accepted: return "메시지 앱에 전송을 요청했습니다. 상대방 수신 여부는 메시지 앱에서 확인하세요."
        case .ready: return "메시지 앱에서 전송 대상을 확인했습니다. 메시지는 보내지 않았습니다."
        case .permissionDenied: return "자동화 권한이 필요합니다. 시스템 설정 → 개인정보 보호 및 보안 → 자동화에서 Synapse의 메시지 접근을 허용하세요."
        case .targetUnavailable: return "메시지 앱에서 같은 대화를 확인할 수 없습니다. 메시지 앱에서 대화를 열고 Synapse를 새로고침하세요."
        case .invalidRequest: return "본문 또는 대화 ID를 확인해 주세요. 공백만 있는 메시지나 16KB를 넘는 본문은 전송할 수 없습니다."
        case .attachmentUnavailable: return "선택한 사진이 변경되었거나 읽을 수 없습니다. 사진을 다시 선택하세요."
        case .unavailable: return "전송 도구를 시작하지 못했습니다. Synapse를 다시 설치한 뒤 시도하세요."
        case .unknown: return "전송 결과를 확인하지 못했습니다. 중복 전송을 피하려면 메시지 앱에서 전송 여부를 먼저 확인하세요. 자동 재전송하지 않습니다."
        }
    }
}

protocol MessageSending: Sendable {
    func send(_ request: SendRequest) async -> SendOutcome
}

// Fixed script; recipient and message are Apple event string descriptors, never source code.
enum MessageScript {
    static let source = """
    on deliverMessage(chatID, messageText, validationOnly, photoPath)
        with timeout of 30 seconds
            try
                tell application id "com.apple.MobileSMS"
                    set targetChat to chat id chatID
                    if (id of targetChat as text) is not equal to chatID then return "targetUnavailable"
                    -- Keep the exact existing chat, including its current SMS/RCS route.
                    -- Do not choose a different account or recipient based on cached service_name.
                    -- Forwarded SMS/RCS account flags can be false while the chat is usable.
                    -- Let Messages evaluate transport availability when handling send.
                end tell
            on error errorText number errorCode
                if errorCode is -1743 then return "permissionDenied"
                return "targetUnavailable"
            end try
            if photoPath is not equal to "" then
                try
                    set photoFile to POSIX file photoPath as alias
                on error
                    return "attachmentUnavailable"
                end try
            end if
            if validationOnly then return "ready"
            try
                tell application id "com.apple.MobileSMS"
                    if photoPath is equal to "" then
                        send messageText to targetChat
                    else
                        send photoFile to targetChat
                    end if
                end tell
                return "accepted"
            on error errorText number errorCode
                if errorCode is -1743 then return "permissionDenied"
                return "unknown"
            end try
        end timeout
    end deliverMessage
    """

    static func event(for request: SendRequest, validationOnly: Bool = false) -> NSAppleEventDescriptor {
        let event = NSAppleEventDescriptor(eventClass: 0x61736372, eventID: 0x70736272,
            targetDescriptor: nil, returnID: -1, transactionID: 0) // ascr / psbr
        event.setParam(NSAppleEventDescriptor(string: "delivermessage"), forKeyword: 0x736e616d) // snam
        let arguments = NSAppleEventDescriptor.list()
        arguments.insert(NSAppleEventDescriptor(string: request.chatID), at: 1)
        arguments.insert(NSAppleEventDescriptor(string: request.text), at: 2)
        arguments.insert(NSAppleEventDescriptor(boolean: validationOnly), at: 3)
        arguments.insert(NSAppleEventDescriptor(string: request.photo?.path ?? ""), at: 4)
        event.setParam(arguments, forKeyword: 0x2d2d2d2d) // ----
        return event
    }
}
