import Foundation

struct SendRequest: Codable, Sendable, Equatable {
    let id: UUID
    let chatID: String
    let text: String

    static let maximumBytes = 16_384
    var isValid: Bool {
        Self.isSupportedChat(chatID) && Self.isValidText(text)
    }
    static func isValidText(_ text: String) -> Bool {
        !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        text.utf8.count <= maximumBytes && !text.contains("\0")
    }
    static func isSupportedChat(_ id: String) -> Bool {
        let parts = id.split(separator: ";", maxSplits: 2, omittingEmptySubsequences: false)
        return parts.count == 3 && parts[0] == "iMessage" &&
            (parts[1] == "+" || parts[1] == "-") && !parts[2].isEmpty &&
            id.utf8.count <= 1024 && !id.unicodeScalars.contains { CharacterSet.controlCharacters.contains($0) }
    }
}

enum SendOutcome: String, Codable, Sendable {
    case accepted, permissionDenied, targetUnavailable, invalidRequest, unavailable, unknown
    var message: String {
        switch self {
        case .accepted: return "메시지 앱에 전송을 요청했습니다. 상대방 수신 여부는 메시지 앱에서 확인하세요."
        case .permissionDenied: return "자동화 권한이 필요합니다. 시스템 설정 → 개인정보 보호 및 보안 → 자동화에서 Synapse의 메시지 접근을 허용하세요."
        case .targetUnavailable: return "메시지 앱에서 같은 iMessage 대화를 확인할 수 없습니다. 메시지 앱의 로그인 상태와 대화를 확인한 뒤 새로고침하세요."
        case .invalidRequest: return "본문 또는 대화 ID를 확인해 주세요. 공백만 있는 메시지나 16KB를 넘는 본문은 전송할 수 없습니다."
        case .unavailable: return "전송 도구를 시작하지 못했습니다. Synapse를 다시 설치한 뒤 시도하세요."
        case .unknown: return "전송 결과를 확인하지 못했습니다. 중복 전송을 피하려면 메시지 앱에서 전송 여부를 먼저 확인하세요. 자동 재전송하지 않습니다."
        }
    }
}

protocol MessageSending: Sendable {
    func send(_ request: SendRequest) async -> SendOutcome
}

// Fixed script; recipient and message are Apple event string descriptors, never source code.
enum MessageScript {
    static let source = """
    on deliverMessage(chatID, messageText)
        with timeout of 30 seconds
            try
                tell application id "com.apple.MobileSMS"
                    set targetChat to chat id chatID
                    if (id of targetChat as text) is not equal to chatID then return "targetUnavailable"
                    set targetAccount to account of targetChat
                    if service type of targetAccount is not iMessage then return "targetUnavailable"
                    if enabled of targetAccount is false then return "targetUnavailable"
                    if connection status of targetAccount is not connected then return "targetUnavailable"
                end tell
            on error errorText number errorCode
                if errorCode is -1743 then return "permissionDenied"
                return "targetUnavailable"
            end try
            try
                tell application id "com.apple.MobileSMS"
                    send messageText to targetChat
                end tell
                return "accepted"
            on error errorText number errorCode
                if errorCode is -1743 then return "permissionDenied"
                return "unknown"
            end try
        end timeout
    end deliverMessage
    """

    static func event(for request: SendRequest) -> NSAppleEventDescriptor {
        let event = NSAppleEventDescriptor(eventClass: 0x61736372, eventID: 0x70736272,
            targetDescriptor: nil, returnID: -1, transactionID: 0) // ascr / psbr
        event.setParam(NSAppleEventDescriptor(string: "delivermessage"), forKeyword: 0x736e616d) // snam
        let arguments = NSAppleEventDescriptor.list()
        arguments.insert(NSAppleEventDescriptor(string: request.chatID), at: 1)
        arguments.insert(NSAppleEventDescriptor(string: request.text), at: 2)
        event.setParam(arguments, forKeyword: 0x2d2d2d2d) // ----
        return event
    }
}
