# Synapse native local alpha

2026-09-06 · 0.1.0 · iMessage 읽기 전용 macOS 앱.

이번 구현은 바로 설치 가능한 DMG로 iMessage의 실현성을 확인하기 위한 SwiftUI 독립 앱이다. 기존 계획의 Tauri/Rust 멀티플랫폼 통합 앱을 완성한 것은 아니다. 개발 환경에 Rust/Cargo가 없고 Apple Swift 도구가 있어 최초 로컬 테스트 경로로 선택했다. 장기 UI/코어 선택은 실제 메시지 테스트 후 재검토한다.

## 구조

- `Sources/MessageStore.swift`: SQLite 읽기 전용 접근, 제한된 typedstream 본문 해독, 메시지 정규화.
- `Sources/SynapseApp.swift`: SwiftUI 대화/검색/권한 안내, 비동기 조회, 연결 상태.
- `Tests/StoreTests.swift`: 임시 합성 DB와 Apple NSArchiver로 만든 테스트 본문. NSArchiver는 fixture 생성에만 사용한다. 앱에는 객체 역직렬화 코드를 포함하지 않는다.
- `scripts/build.sh`: 앱 번들 생성, 아이콘 생성, ad-hoc 코드 서명 및 검증.
- `scripts/test.sh`: 네이티브 데이터 계층 검증.
- `scripts/package.sh`: 장치를 마운트하지 않고 HFS 이미지 생성 후 UDZO DMG 변환·검증.
- `INSTALL.md`: 사용자 설치 방법, 검증 결과 및 한계.

## 재현

필요 도구: Apple Silicon Mac, Xcode/Command Line Tools의 Swift 컴파일러, macOS 기본 hdiutil/codesign. 외부 패키지 다운로드가 없다. 검증 환경: Swift 6.3.3, macOS 26.6.2. 최소 배포 대상 macOS 13은 실기기 검증 전이다.

프로젝트 루트에서:

```sh
bash native/scripts/test.sh
bash native/scripts/build.sh
bash native/scripts/package.sh
```

기본 결과: `native/build/Synapse.app`, `native/build/Synapse-0.1.0-arm64.dmg`. 각 스크립트의 첫 인수로 별도 빌드 디렉터리를 지정할 수 있다. 패키징은 먼저 앱을 빌드한다.

## 구현 상태

P0-02의 합성 데이터 읽기/본문 해독과 P0-05의 SwiftUI 대체 경로 패키징을 수행했다. 실제 개인 DB·권한 철회·잠자기/재연결은 아직 미검증이며 iMessage 전체 지원 완료로 표시하지 않는다. Telegram·암호화 검색 저장소·발신·15개 서비스 구현은 포함하지 않는다.

메시지를 디스크에 복제하지 않는 메모리 조회 방식이다. SQLite가 WAL 읽기에 필요한 공유 메모리 잠금을 사용할 수 있으므로 원본 디렉터리 전체의 바이트 불변까지 보장하지 않는다. DB를 immutable로 열거나 원본에 checkpoint를 실행하지 않는다.

제품 UI는 읽기 권한을 필요 시 안내한다. 기본 샘플에서 실제 DB를 자동으로 열지 않으며 발신 기능과 임의 셸 실행 IPC가 없다. 알 수 없는 본문은 추측해 표시하지 않고 미지원으로 표시한다.
