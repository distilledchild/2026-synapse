#!/bin/bash
set -euo pipefail
source_root="$(cd "$(dirname "$0")/.." && pwd)"
build_root="${1:-$source_root/build}"
mkdir -p "$build_root/module-cache"
swiftc -suppress-warnings -module-cache-path "$build_root/module-cache" -target arm64-apple-macosx13.0 \
    -parse-as-library "$source_root/Sources/MessageStore.swift" "$source_root/Tests/StoreTests.swift" \
    -o "$build_root/store-tests" -lsqlite3
"$build_root/store-tests"
