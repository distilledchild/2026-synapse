#!/bin/bash
set -euo pipefail
source_root="$(cd "$(dirname "$0")/.." && pwd)"
build_root="${1:-$source_root/build}"
mkdir -p "$build_root/module-cache" "$build_root/Synapse.app/Contents/MacOS" "$build_root/Synapse.app/Contents/Resources"
swiftc -module-cache-path "$build_root/module-cache" -target arm64-apple-macosx13.0 -O -parse-as-library \
    "$source_root/Sources/MessageStore.swift" "$source_root/Sources/SynapseApp.swift" \
    -o "$build_root/Synapse.app/Contents/MacOS/Synapse" -framework SwiftUI -framework AppKit -lsqlite3
cp "$source_root/Resources/Info.plist" "$build_root/Synapse.app/Contents/Info.plist"
swift -module-cache-path "$build_root/module-cache" "$source_root/scripts/make-icon.swift" "$build_root/AppIcon.iconset" "$build_root/Synapse.app/Contents/Resources/AppIcon.icns"
codesign --force --sign - --timestamp=none "$build_root/Synapse.app"
codesign --verify --deep --strict "$build_root/Synapse.app"
