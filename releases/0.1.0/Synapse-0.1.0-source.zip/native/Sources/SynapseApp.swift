import SwiftUI
import AppKit
import UniformTypeIdentifiers

@MainActor
final class InboxModel: ObservableObject {
    @Published var snapshot = MessageStore.demo
    @Published var selectedID: String? = "team"
    @Published var search = ""
    @Published var isDemo = true
    @Published var isLoading = false
    @Published var error: String?
    @Published var lastUpdated: Date?
    @Published var autoRefresh = true
    private var path: String?
    private var generation = 0
    private var timer: Timer?

    init() {
        timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.autoRefresh, !self.isDemo, !self.isLoading else { return }
                self.refresh()
            }
        }
    }
    var conversations: [Conversation] {
        Dictionary(grouping: snapshot.messages, by: \.conversationID).map { key, messages in
            Conversation(id: key, title: messages.last!.conversationTitle, messages: messages)
        }.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.messages.contains { $0.text.localizedCaseInsensitiveContains(search) } }
        .sorted { ($0.last.date ?? .distantPast) > ($1.last.date ?? .distantPast) }
    }
    var selected: Conversation? { conversations.first { $0.id == selectedID } }
    func connect(path: String? = nil) {
        generation += 1
        self.path = path ?? FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Messages/chat.db").path
        isDemo = false
        snapshot = Snapshot(messages: [], sourceRows: 0, limit: 2000)
        selectedID = nil
        error = nil
        lastUpdated = nil
        refresh()
    }
    func refresh() {
        guard let path else { return }
        generation += 1
        let token = generation
        isLoading = true
        Task {
            let result = await Task.detached(priority: .userInitiated) { () -> Result<Snapshot, Error> in
                Result { try MessageStore.load(path: path) }
            }.value
            guard token == generation else { return }
            isLoading = false
            switch result {
            case .success(let value):
                snapshot = value; error = nil; lastUpdated = Date()
                if !conversations.contains(where: { $0.id == selectedID }) { selectedID = conversations.first?.id }
            case .failure(let failure):
                snapshot = Snapshot(messages: [], sourceRows: 0, limit: 2000)
                selectedID = nil
                error = failure.localizedDescription
            }
        }
    }
    func disconnect() {
        generation += 1; path = nil; isLoading = false; error = nil; isDemo = true
        snapshot = MessageStore.demo; selectedID = "team"; search = ""; lastUpdated = nil
    }
    func chooseDatabase() {
        let panel = NSOpenPanel()
        panel.title = "메시지 데이터베이스 선택"
        panel.message = "읽기 권한이 있는 macOS chat.db 파일을 선택하세요. 원본에는 쓰지 않습니다."
        panel.canChooseDirectories = false; panel.allowsMultipleSelection = false
        if panel.runModal() == .OK, let url = panel.url { connect(path: url.path) }
    }
    func openPrivacy() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles") { NSWorkspace.shared.open(url) }
    }
}

struct InboxView: View {
    @StateObject private var model = InboxModel()
    @State private var showHelp = false
    private let accent = Color(red: 0.43, green: 0.34, blue: 0.88)
    var body: some View {
        NavigationSplitView {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 10) {
                    Image(systemName: "bubble.left.and.bubble.right.fill").font(.system(size: 24)).foregroundStyle(accent)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Synapse").font(.system(size: 23, weight: .bold, design: .rounded))
                        Text("모든 대화의 시작").font(.caption).foregroundStyle(.secondary)
                    }
                }.padding(20)
                HStack {
                    Label("iMessage", systemImage: "message.fill").font(.headline)
                    Spacer()
                    Text(model.isDemo ? "샘플" : model.error == nil ? "연결됨" : "연결 필요")
                        .font(.caption2.bold()).padding(.horizontal, 8).padding(.vertical, 4)
                        .background(accent.opacity(0.12), in: Capsule()).foregroundStyle(accent)
                }.padding(.horizontal, 20).padding(.bottom, 12)
                TextField("대화·메시지 검색", text: $model.search)
                    .textFieldStyle(.roundedBorder).padding(.horizontal, 16).padding(.bottom, 12)
                List(selection: $model.selectedID) {
                    ForEach(model.conversations) { conversation in
                        HStack(alignment: .top, spacing: 11) {
                            ZStack {
                                Circle().fill(accent.opacity(0.12)).frame(width: 36, height: 36)
                                Text(String(conversation.title.prefix(1))).font(.headline).foregroundStyle(accent)
                            }
                            VStack(alignment: .leading, spacing: 5) {
                                Text(conversation.title).font(.system(size: 13, weight: .semibold)).lineLimit(1)
                                Text(conversation.last.text).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(2)
                            }
                            Spacer(minLength: 0)
                        }.padding(.vertical, 7).tag(conversation.id)
                    }
                }.listStyle(.sidebar)
                Divider()
                VStack(alignment: .leading, spacing: 10) {
                    if model.isDemo {
                        Button { model.connect() } label: {
                            Label("iMessage 연결", systemImage: "link").frame(maxWidth: .infinity)
                        }.buttonStyle(.borderedProminent).tint(accent).controlSize(.large)
                    } else {
                        HStack {
                            Toggle("자동 새로고침", isOn: $model.autoRefresh).toggleStyle(.switch).controlSize(.mini)
                            Spacer()
                            Button("연결 해제") { model.disconnect() }.font(.caption)
                        }
                    }
                    HStack {
                        Label("이 Mac에서만 처리", systemImage: "lock.shield").font(.caption).foregroundStyle(.secondary)
                        Spacer()
                        Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }.buttonStyle(.plain)
                    }
                }.padding(16)
            }.navigationSplitViewColumnWidth(min: 260, ideal: 300, max: 380)
        } detail: {
            VStack(spacing: 0) {
                if model.isDemo {
                    HStack {
                        Image(systemName: "sparkles")
                        Text("샘플 대화입니다. iMessage를 연결하면 실제 대화를 읽어옵니다.")
                        Spacer()
                    }.font(.callout).padding(14).background(accent.opacity(0.08))
                }
                if let error = model.error {
                    permissionView(error)
                } else if model.isLoading && model.snapshot.messages.isEmpty {
                    Spacer(); ProgressView("메시지를 읽고 있습니다…"); Spacer()
                } else if let conversation = model.selected {
                    conversationView(conversation)
                } else {
                    Spacer()
                    Image(systemName: "bubble.left.and.text.bubble.right").font(.system(size: 48)).foregroundStyle(accent.opacity(0.6))
                    Text(model.search.isEmpty ? "표시할 대화가 없습니다" : "검색 결과가 없습니다").font(.title2.bold()).padding(.top, 12)
                    Text(model.search.isEmpty ? "메시지 앱의 동기화 상태를 확인하거나 다른 데이터베이스를 선택하세요." : "검색은 불러온 최근 메시지 안에서 수행됩니다.")
                        .foregroundStyle(.secondary).padding().multilineTextAlignment(.center)
                    Spacer()
                }
                Divider()
                HStack(spacing: 12) {
                    Circle().fill(model.error != nil ? Color.orange : model.isDemo ? Color.gray : Color.green).frame(width: 6, height: 6)
                    Text(model.isDemo ? "샘플 \(model.snapshot.sourceRows)개" : "최근 \(model.snapshot.sourceRows)개 메시지 · 최대 \(model.snapshot.limit)개")
                    if model.snapshot.unavailableCount > 0 { Text("본문 미지원 \(model.snapshot.unavailableCount)개").foregroundStyle(.orange) }
                    Spacer()
                    if model.isLoading { ProgressView().controlSize(.small) }
                    if let date = model.lastUpdated { Text(date, style: .time) }
                    Text("읽기 전용 · 로컬 알파").foregroundStyle(.secondary)
                }.font(.caption).foregroundStyle(.secondary).padding(12)
            }.frame(minWidth: 540)
        }
        .frame(minWidth: 900, minHeight: 620)
        .toolbar {
            ToolbarItemGroup {
                Button { model.chooseDatabase() } label: { Label("DB 선택", systemImage: "folder") }.help("다른 chat.db 파일 선택")
                Button { model.refresh() } label: { Label("새로고침", systemImage: "arrow.clockwise") }
                    .disabled(model.isDemo || model.isLoading).keyboardShortcut("r", modifiers: .command)
                Button { showHelp = true } label: { Label("도움말", systemImage: "info.circle") }
            }
        }
        .sheet(isPresented: $showHelp) { helpView }
        .onChange(of: model.search) { _ in
            if !model.conversations.contains(where: { $0.id == model.selectedID }) { model.selectedID = model.conversations.first?.id }
        }
    }
    private func permissionView(_ message: String) -> some View {
        VStack(alignment: .leading, spacing: 20) {
            Spacer()
            Image(systemName: "lock.shield").font(.system(size: 44)).foregroundStyle(accent)
            Text("메시지 접근을 허용해 주세요").font(.title.bold())
            Text(message).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            VStack(alignment: .leading, spacing: 12) {
                Text("1. Synapse를 응용 프로그램 폴더로 옮겨 실행하세요.")
                Text("2. 시스템 설정 → 개인정보 보호 및 보안 → 전체 디스크 접근 권한에서 Synapse를 추가하고 켜세요.")
                Text("3. Synapse를 완전히 종료한 뒤 다시 열고, iMessage를 연결하세요.")
            }.font(.callout)
            HStack {
                Button("시스템 설정 열기") { model.openPrivacy() }.buttonStyle(.borderedProminent).tint(accent)
                Button("다시 시도") { model.refresh() }
                Button("샘플로 돌아가기") { model.disconnect() }
            }
            Text("메시지 원본은 변경하지 않습니다. 권한을 켜도 자동으로 발신하지 않습니다.").font(.caption).foregroundStyle(.secondary)
            Spacer()
        }.padding(44).frame(maxWidth: 720, maxHeight: .infinity)
    }
    private func conversationView(_ conversation: Conversation) -> some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(conversation.title).font(.title2.bold()).textSelection(.enabled)
                    Text("iMessage · 불러온 메시지 \(conversation.messages.count)개").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "message.fill").foregroundStyle(.green).font(.title2)
            }.padding(24)
            Divider()
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 16) {
                        ForEach(conversation.messages.filter { model.search.isEmpty || conversation.title.localizedCaseInsensitiveContains(model.search) || $0.text.localizedCaseInsensitiveContains(model.search) }) { message in
                            HStack(alignment: .bottom) {
                                if message.isFromMe { Spacer(minLength: 70) }
                                VStack(alignment: message.isFromMe ? .trailing : .leading, spacing: 5) {
                                    if !message.isFromMe { Text(message.sender).font(.caption2).foregroundStyle(.secondary).lineLimit(1) }
                                    VStack(alignment: .leading, spacing: 7) {
                                        Text(message.text).font(.system(size: 14)).textSelection(.enabled).fixedSize(horizontal: false, vertical: true)
                                        if message.hasAttachment { Label("첨부 미리보기는 다음 버전에 제공됩니다", systemImage: "paperclip").font(.caption2) }
                                        if message.bodyUnavailable { Label("지원하지 않는 본문 형식", systemImage: "exclamationmark.circle").font(.caption2) }
                                    }.padding(.horizontal, 16).padding(.vertical, 12)
                                        .foregroundStyle(message.isFromMe ? Color.white : Color.primary)
                                        .background(message.isFromMe ? accent : Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 17))
                                    if let date = message.date { Text(date.formatted(date: .abbreviated, time: .shortened)).font(.caption2).foregroundStyle(.secondary) }
                                }.frame(maxWidth: 540, alignment: message.isFromMe ? .trailing : .leading)
                                if !message.isFromMe { Spacer(minLength: 70) }
                            }.id(message.id)
                        }
                    }.padding(24)
                }
                .onChange(of: conversation.id) { _ in if let last = conversation.messages.last, model.search.isEmpty { proxy.scrollTo(last.id, anchor: .bottom) } }
                .onAppear { if let last = conversation.messages.last, model.search.isEmpty { proxy.scrollTo(last.id, anchor: .bottom) } }
            }
            HStack {
                Image(systemName: "eye")
                Text("읽기 전용 테스트판입니다. 답장은 메시지 앱에서 보내세요.")
                Spacer()
                Button("메시지 앱 열기") { if let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: "com.apple.MobileSMS") { NSWorkspace.shared.openApplication(at: url, configuration: NSWorkspace.OpenConfiguration()) } }
            }.font(.caption).foregroundStyle(.secondary).padding(16)
        }
    }
    private var helpView: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Synapse 로컬 테스트 안내").font(.title2.bold())
            Text("iMessage의 최근 2,000개 메시지를 읽고, 대화별로 확인하고 검색합니다. 연결 중에는 5초마다 갱신합니다.")
            Text("본문과 대화는 메모리에서만 처리합니다. 별도 대화 캐시나 외부 서버 전송은 없습니다. 연결 해제 시 불러온 대화를 지웁니다.")
            Text("일반 텍스트와 표준 attributedBody 문자열을 지원합니다. 일부 특수 메시지·본문 형식, 첨부 미리보기, 답장·리액션 전송은 아직 지원하지 않습니다.")
            Text("SMS·RCS 표시 여부는 Apple 메시지 앱의 동기화 및 iPhone 전달 설정에 따라 달라집니다. 이 앱은 메시지 앱이 가진 데이터만 읽습니다.")
            Text("개인 개발용 서명으로 만든 공증되지 않은 Apple Silicon 테스트판입니다.").font(.caption).foregroundStyle(.secondary)
            HStack { Spacer(); Button("확인") { showHelp = false }.keyboardShortcut(.defaultAction) }
        }.padding(30).frame(width: 570)
    }
}

@main
struct SynapseApp: App {
    var body: some Scene {
        WindowGroup("Synapse") { InboxView().tint(Color(red: 0.43, green: 0.34, blue: 0.88)) }
            .defaultSize(width: 1120, height: 760)
            .commands { CommandGroup(replacing: .newItem) {} }
    }
}
